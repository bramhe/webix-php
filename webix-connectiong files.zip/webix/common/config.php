<?php
/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
This version of Software is free for using in non-commercial applications.
For commercial use please contact sales@dhtmlx.com to obtain license
*/

$mysql_host = "localhost";
$mysql_user = "siddhi";
$mysql_pasw = "qaz123";
$mysql_db   = "siddhi";

?>
